$(window).resize(function() {
    
    var ctx1 = document.getElementById("chart1").getContext("2d");
    var data1 = {
        labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        datasets: [
            {
                label: "My Second dataset",
                fillColor: "#663399",
                strokeColor: "#663399",
                pointColor: "#663399",
                pointStrokeColor: "#323A92",
                pointHighlightFill: "#663399",
                pointHighlightStroke: "rgba(243,245,246,0.9)",
                data: [69, 71, 72, 75, 77, 81, 84, 86, 89, 93]
            },
            {
                label: "My First dataset",
                fillColor: "#21A6F3",
                strokeColor: "#21A6F3",
                pointColor: "#21A6F3",
                pointStrokeColor: "#323A92",
                pointHighlightFill: "##21A6F3",
                pointHighlightStroke: "rgba(255,127,90,1)",
                data: [66, 70, 73, 76, 77, 82, 85, 87, 89, 92]
            }
            
        ]
    };
    
    var chart1 = new Chart(ctx1).Line(data1, {
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.005)",
        scaleGridLineWidth : 0,
        scaleShowHorizontalLines: true,
        scaleShowVerticalLines: true,
        bezierCurve : false,
        pointDot : true,
        pointDotRadius : 5,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 2,
        datasetStroke : true,
		tooltipCornerRadius: 1,
        datasetStrokeWidth : 1,
        datasetFill : false,
        legendTemplate : "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].strokeColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
        responsive: true
    });
    
    var ctx2 = document.getElementById("chart2").getContext("2d");
    var data2 = {
        labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        datasets: [
            {
                label: "First",
                fillColor: "#663399",
                strokeColor: "#663399",
                pointColor: "#663399",
                pointStrokeColor: "#323A92",
                pointHighlightFill: "#663399",
                pointHighlightStroke: "rgba(243,245,246,0.9)",
                data: [30, 20, 12, 11, 10, 8, 6, 3, 2, 1]
            },
            {
                label: "Second",
                fillColor: "#21A6F3",
                strokeColor: "#21A6F3",
                pointColor: "#21A6F3",
                pointStrokeColor: "#323A92",
                pointHighlightFill: "##21A6F3",
                pointHighlightStroke: "rgba(255,127,90,1)",
                data: [28, 18, 15, 12, 12, 9, 6, 5, 4, 2]
            }
        ]
    };
    
    var chart2 = new Chart(ctx2).Line(data2, {
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.005)",
        scaleGridLineWidth : 0,
        scaleShowHorizontalLines: true,
        scaleShowVerticalLines: true,
        bezierCurve : false,
        pointDot : true,
        pointDotRadius : 5,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 2,
        datasetStroke : true,
        tooltipCornerRadius: 1,
        datasetStrokeWidth : 1,
        datasetFill : false,
        legendTemplate : "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].strokeColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
        responsive: true
    });   
});